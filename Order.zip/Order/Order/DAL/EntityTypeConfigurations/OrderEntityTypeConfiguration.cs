using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Order.DAL.DbConstants;

namespace Order.DAL.EntityTypeConfigurations;

public class OrderEntityTypeConfiguration : IEntityTypeConfiguration<Models.Order>
{
    public void Configure(EntityTypeBuilder<Models.Order> entityTypeBuilder)
    {
        entityTypeBuilder.ToTable("Order");

        entityTypeBuilder.HasKey(k => k.Id).HasName("PK_Order");

        entityTypeBuilder
            .Property(p => p.Id)
            .HasColumnType(StringConstants.Int)
            .UseMySqlIdentityColumn();
        
        entityTypeBuilder
            .Property(p => p.OrderDateTime)
            .HasColumnType(StringConstants.DateTime)
            .IsRequired();
        
        entityTypeBuilder
            .Property(p => p.Total)
            .HasColumnType(StringConstants.Long)
            .IsRequired();
        
    }
}