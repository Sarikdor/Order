using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Order.DAL.DbConstants;
using Order.DAL.Models;

namespace Order.DAL.EntityTypeConfigurations;

public class CategoryEntityTypeConfiguration : IEntityTypeConfiguration<Category>
{
    public void Configure(EntityTypeBuilder<Category> entityTypeBuilder)
    {
        entityTypeBuilder.ToTable("Category");

        entityTypeBuilder.HasKey(k => k.Id).HasName("PK_Category");

        entityTypeBuilder
            .Property(p => p.Id)
            .HasColumnType(StringConstants.Int)
            .UseMySqlIdentityColumn();
        entityTypeBuilder
            .Property(p => p.Name)
            .HasColumnType(StringConstants.Varchar20)
            .IsRequired();
        entityTypeBuilder
            .HasMany(opt => opt.Products)
            .WithOne(opt => opt.Category)
            .HasForeignKey(opt => opt.CategoryId).IsRequired();
    }
}