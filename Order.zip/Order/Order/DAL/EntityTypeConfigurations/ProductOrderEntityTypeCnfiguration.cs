using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Order.DAL.Models;

namespace Order.DAL.EntityTypeConfigurations;

public class ProductOrderEntityTypeConfiguration : IEntityTypeConfiguration<ProductOrder>
{
    public void Configure(EntityTypeBuilder<ProductOrder> entityTypeBuilder)
    {
        entityTypeBuilder.ToTable("ProductOrder");
    }
}