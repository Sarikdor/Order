using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Order.DAL.DbConstants;
using Order.DAL.Models;

namespace Order.DAL.EntityTypeConfigurations;

public class ProductEntityTypeConfiguration : IEntityTypeConfiguration<Product>
{
    public void Configure(EntityTypeBuilder<Product> entityTypeBuilder)
    {
        entityTypeBuilder.ToTable("Product");

        entityTypeBuilder.HasKey(k => k.Id).HasName("PK_Product");

        entityTypeBuilder
            .Property(p => p.Id)
            .HasColumnType(StringConstants.Int)
            .UseMySqlIdentityColumn();
        entityTypeBuilder
            .Property(p => p.Name)
            .HasColumnType(StringConstants.Varchar20)
            .IsRequired();
        entityTypeBuilder
            .Property(p => p.Details)
            .HasColumnType(StringConstants.Varchar200)
            .IsRequired();
        entityTypeBuilder
            .Property(p => p.Price)
            .HasColumnType(StringConstants.Long)
            .IsRequired();
        
        entityTypeBuilder
            .HasOne(p => p.Category)
            .WithMany(opt => opt.Products)
            .HasForeignKey(p => p.CategoryId).IsRequired();

    }
}