namespace Order.DAL.Models;

public class Order
{
    public int Id { get; set; }
    public int Total { get; set; }
    public DateTime OrderDateTime { get; set; }
    public virtual IEnumerable<Product> Products { get; set; }
    public virtual IEnumerable<ProductOrder> ProductOrders { get; set; }
    
}