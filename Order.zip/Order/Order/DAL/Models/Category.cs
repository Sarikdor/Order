namespace Order.DAL.Models;

public class Category
{
    public int Id { get; set; }
    public string Name { get; set; }
    
    public int ProductId { get; set; }
    
    public virtual IEnumerable<Product> Products { get; set; }
}