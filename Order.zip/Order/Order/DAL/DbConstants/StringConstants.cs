namespace Order.DAL.DbConstants;

public class StringConstants
{
    internal const string Int = "int";
    internal const string Long = "bigint";
    internal const string DateTime = "datetime";
    internal const string Varchar20 = "varchar(20)";
    internal const string Varchar200 = "varchar(200)";
}