using Microsoft.EntityFrameworkCore;
using Order.DAL.Models;

namespace Order.DAL.DbServices;

public partial class DatabaseService
{
    #region Get

    public async Task<Models.Order> GetOrder(int id)
    {
        return await _context.Orders
            .Include(e => e.Products)
            .FirstOrDefaultAsync(e => e.Id == id);
    }

    public async Task<IEnumerable<Models.Order>> GetOrders()
    {
        return await _context.Orders
            .Include(e => e.Products)
            .ToListAsync();
    }
    

    #endregion
    
    #region Add

    public async Task<int> AddOrder(Models.Order order)
    {
        await _context.Orders.AddAsync(order);
        return await _context.SaveChangesAsync();
    }

    public async Task<int> AddOrders(IEnumerable<Models.Order> orders)
    {
        await _context.Orders.AddRangeAsync(orders);
        return await _context.SaveChangesAsync();
    }

    #endregion
    
    #region Update

    public async Task<int> UpdateOrder(Models.Order order)
    { 
        _context.Orders.Update(order);
        return await _context.SaveChangesAsync();
    }

    public async Task<int> UpdateOrders(IEnumerable<Models.Order> orders)
    {
        _context.Orders.UpdateRange(orders);
        return await _context.SaveChangesAsync();
    }
    
    #endregion
    
    #region Delete

    public async Task<int> RemoveOrder(Models.Order order)
    { 
        _context.Orders.Remove(order);
        return await _context.SaveChangesAsync();
    }

    public async Task<int> RemoveOrders(IEnumerable<Models.Order> orders )
    {
        _context.Orders.RemoveRange(orders);
        return await _context.SaveChangesAsync();
    }

    #endregion
}