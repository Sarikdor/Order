using Microsoft.EntityFrameworkCore;
using Order.DAL.Models;

namespace Order.DAL.DbServices;

public partial class DatabaseService
{
    #region Get

    public async Task<ProductOrder> GetProductOrder(int id)
    {
        return await _context.ProductOrders
            .Include(e => e.Product)
            .Include(e => e.Order)
            .FirstOrDefaultAsync(e => e.ProductId == id);
    }

    public async Task<IEnumerable<ProductOrder>> GetProductOrders()
    {
        return await _context.ProductOrders
            .Include(e => e.Product)
            .Include(e => e.Order)
            .ToListAsync();
    }

    // public async Task<IEnumerable<ProductOrder>> GetProductOrderByName(string name)
    // {
    //     return await _context.ProductOrders
    //         .Include(e => e.Product)
    //         
    //         .ToListAsync();
    // }

    #endregion
    
    #region Add

    public async Task<int> AddProductOrder(ProductOrder productOrder)
    {
        await _context.ProductOrders.AddAsync(productOrder);
        return await _context.SaveChangesAsync();
    }

    public async Task<int> AddProductOrders(IEnumerable<ProductOrder> productOrders)
    {
        await _context.ProductOrders.AddRangeAsync(productOrders);
        return await _context.SaveChangesAsync();
    }

    #endregion
    
    #region Update

    public async Task<int> UpdateProductOrder(ProductOrder productOrder)
    { 
        _context.ProductOrders.Update(productOrder);
        return await _context.SaveChangesAsync();
    }

    public async Task<int> UpdateProductOrders(IEnumerable<ProductOrder> productOrders)
    {
        _context.ProductOrders.UpdateRange(productOrders);
        return await _context.SaveChangesAsync();
    }
    
    #endregion
    
    #region Delete

    public async Task<int> RemoveProductOrder(ProductOrder productOrder)
    { 
        _context.ProductOrders.Remove(productOrder);
        return await _context.SaveChangesAsync();
    }

    public async Task<int> RemoveProductOrders(IEnumerable<ProductOrder> productOrders)
    {
        _context.ProductOrders.RemoveRange(productOrders);
        return await _context.SaveChangesAsync();
    }

    #endregion
}