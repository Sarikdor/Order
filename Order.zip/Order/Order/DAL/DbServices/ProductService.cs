using Microsoft.EntityFrameworkCore;
using Order.DAL.Models;

namespace Order.DAL.DbServices;

public partial class DatabaseService
{
    #region Get

    public async Task<Product> GetProduct(int id)
    {
        return await _context.Products
            .Include(e => e.Orders)
            .Include(e => e.Category)
            .FirstOrDefaultAsync(e => e.Id == id);
    }

    public async Task<IEnumerable<Product>> GetProducts()
    {
        return await _context.Products
            .Include(e => e.Category)
            .Include(e => e.Orders)
            .ToListAsync();
    }

    public async Task<IEnumerable<Product>> GetProductByName(string name)
    {
        return await _context.Products
            .Include(e => e.Category)
            .Include(e => e.Orders)
            .Where(e => e.Name.Contains(name, StringComparison.OrdinalIgnoreCase))
            .ToListAsync();
    }

    #endregion
    
    #region Add

    public async Task<int> AddProduct(Product Product)
    {
        await _context.Products.AddAsync(Product);
        return await _context.SaveChangesAsync();
    }

    public async Task<int> AddProducts(IEnumerable<Product> Products)
    {
        await _context.Products.AddRangeAsync(Products);
        return await _context.SaveChangesAsync();
    }

    #endregion
    
    #region Update

    public async Task<int> UpdateProduct(Product Product)
    { 
        _context.Products.Update(Product);
        return await _context.SaveChangesAsync();
    }

    public async Task<int> UpdateProducts(IEnumerable<Product> Products)
    {
        _context.Products.UpdateRange(Products);
        return await _context.SaveChangesAsync();
    }
    
    #endregion
    
    #region Delete

    public async Task<int> RemoveProduct(Product Product)
    { 
        _context.Products.Remove(Product);
        return await _context.SaveChangesAsync();
    }

    public async Task<int> RemoveProducts(IEnumerable<Product> Products)
    {
        _context.Products.RemoveRange(Products);
        return await _context.SaveChangesAsync();
    }

    #endregion
}