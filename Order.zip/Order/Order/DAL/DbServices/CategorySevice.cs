using Microsoft.EntityFrameworkCore;
using Order.DAL.Models;

namespace Order.DAL.DbServices;

public partial class DatabaseService
{
    #region Get

    public async Task<Category> GetCategory(int id)
    {
        return await _context.Categories
            .Include(e => e.Products)
            .FirstOrDefaultAsync(e => e.Id == id);
    }

    public async Task<IEnumerable<Category>> GetCategories()
    {
        return await _context.Categories
            .Include(e => e.Products)
            .ToListAsync();
    }

    public async Task<IEnumerable<Category>> GetCategoryByName(string name)
    {
        return await _context.Categories
            .Include(e => e.Products)
            .Where(e => e.Name.Contains(name, StringComparison.OrdinalIgnoreCase))
            .ToListAsync();
    }

    #endregion
    
    #region Add

    public async Task<int> AddCategory(Category category)
    {
        await _context.Categories.AddAsync(category);
        return await _context.SaveChangesAsync();
    }

    public async Task<int> AddCategories(IEnumerable<Category> categories)
    {
        await _context.Categories.AddRangeAsync(categories);
        return await _context.SaveChangesAsync();
    }

    #endregion
    
    #region Update

    public async Task<int> UpdateCategory(Category category)
    { 
        _context.Categories.Update(category);
        return await _context.SaveChangesAsync();
    }

    public async Task<int> UpdateCategories(IEnumerable<Category> categories)
    {
         _context.Categories.UpdateRange(categories);
        return await _context.SaveChangesAsync();
    }
    
    #endregion
    
    #region Delete

    public async Task<int> RemoveCategory(Category category)
    { 
        _context.Categories.Remove(category);
        return await _context.SaveChangesAsync();
    }

    public async Task<int> RemoveCategories(IEnumerable<Category> categories)
    {
        _context.Categories.RemoveRange(categories);
        return await _context.SaveChangesAsync();
    }

    #endregion
}