namespace Order.ViewModel;

public class ViewOrder
{
    public int Id { get; set; }
    public int Total { get; set; }
    public DateTime OrderDateTime { get; set; }
}