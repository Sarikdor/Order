namespace Order.ViewModel;

public class ViewCategory
{
    public int Id { get; set; }
    public string Name { get; set; }
    
    public int ProductId { get; set; }
}