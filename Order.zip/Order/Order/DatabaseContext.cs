using Microsoft.EntityFrameworkCore;
using Order.DAL.Models;
namespace Order;

public class DatabaseContext : DbContext
{
    public DbSet<DAL.Models.Order> Orders { get; set; }
    public DbSet<Product> Products { get; set; }
    public DbSet<ProductOrder> ProductOrders { get; set; }
    public DbSet<Category> Categories { get; set; }

    public DatabaseContext(DbContextOptions<DatabaseContext> options) : base(options)
    {
        
    }

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<ProductOrder>()
            .HasKey(bc => new { bc.OrderId, bc.ProductId });
        modelBuilder.Entity<ProductOrder>()
            .HasOne(bc => bc.Order)
            .WithMany(bc => bc.ProductOrders)
            .HasForeignKey(bc => bc.ProductId);
        modelBuilder.Entity<ProductOrder>()
            .HasOne(bc => bc.Product)
            .WithMany(bc => bc.ProductOrders)
            .HasForeignKey(bc => bc.OrderId);
    }
  }