using AutoMapper;
using Microsoft.AspNetCore.Mvc;
using Order.DAL.DbServices;
using Order.ViewModel;

namespace Order.Controllers;
[ApiController]
[Route("api/[controller]")]
public class OrderController : Controller
{
    private readonly IMapper _mapper;
    private readonly DatabaseService _databaseService;

    public OrderController(IMapper mapper, DatabaseContext databaseContext)
    {
        _mapper = mapper;
        _databaseService = new DatabaseService(databaseContext);
    }
    
    #region Get

    [Route("GetOrder/{id}")]
    [HttpGet]
    public async Task<DAL.Models.Order> GetOrder(int id)
    {
        return await _databaseService.GetOrder(id);
    }

    [Route("GetOrders")]
    [HttpGet]
    public async Task<IEnumerable<DAL.Models.Order>> GetOrders()
    {
        return await _databaseService.GetOrders();
    }

    // [Route("GetOrder/{name}")]
    // [HttpGet]
    // public async Task<IEnumerable<DAL.Models.Order>> GetOrdersByName(string name)
    // {
    //     return await _databaseService.GetOrderByName(name);
    // }


    #endregion
    
    #region Add

    [Route("AddOrder")]
    [HttpPost]
    public async Task<IActionResult> AddOrder(ViewOrder viewOrder)
    {
        var order = _mapper.Map<DAL.Models.Order>(viewOrder);
        var result = await _databaseService.AddOrder(order);
        return result > 0 ? new StatusCodeResult(200) : new StatusCodeResult(500);
    }
    
    [Route("AddOrders")]
    [HttpPost]
    public async Task<IActionResult> AddOrder(IEnumerable<ViewOrder> viewOrders)
    {
        var orders = _mapper.Map<IEnumerable<DAL.Models.Order>>(viewOrders);
        var result = await _databaseService.AddOrders(orders);
        return result > 0 ? new StatusCodeResult(200) : new StatusCodeResult(500);
    }
    #endregion

    #region Update

    [Route("UpdateOrder")]
    [HttpPost]
    public async Task<IActionResult> UpdateOrder(ViewOrder viewOrder)
    {
        var order = _mapper.Map<DAL.Models.Order>(viewOrder);
        var result = await _databaseService.UpdateOrder(order);
        return result > 0 ? new StatusCodeResult(200) : new StatusCodeResult(500);
    }
    
    [Route("UpdateOrders")]
    [HttpPost]
    public async Task<IActionResult> UpdateOrders(IEnumerable<ViewOrder> viewOrders)
    {
        var orders = _mapper.Map<IEnumerable<DAL.Models.Order>>(viewOrders);
        var result = await _databaseService.UpdateOrders(orders);
        return result > 0 ? new StatusCodeResult(200) : new StatusCodeResult(500);
    }

    #endregion

    #region Delete

    [Route("DeleteOrder")]
    [HttpPost]
    public async Task<IActionResult> DeleteOrder(ViewOrder viewOrder)
    {
        var order = _mapper.Map<DAL.Models.Order>(viewOrder);
        var result = await _databaseService.RemoveOrder(order);
        return result > 0 ? new StatusCodeResult(200) : new StatusCodeResult(500);
    }
    
    [Route("DeleteOrders")]
    [HttpPost]
    public async Task<IActionResult> DeleteOrder(IEnumerable<ViewOrder> viewOrders)
    {
        var orders = _mapper.Map<IEnumerable<DAL.Models.Order>>(viewOrders);
        var result = await _databaseService.RemoveOrders(orders);
        return result > 0 ? new StatusCodeResult(200) : new StatusCodeResult(500);
    }

    #endregion
}