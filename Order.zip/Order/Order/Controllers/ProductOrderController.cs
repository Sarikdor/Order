using AutoMapper;
using Microsoft.AspNetCore.Mvc;
using Order.DAL.DbServices;
using Order.DAL.Models;
using Order.ViewModel;

namespace Order.Controllers;

[ApiController]
[Route("api/[controller]")]
public class ProductOrderController : Controller
{
    private readonly IMapper _mapper;
    private readonly DatabaseService _databaseService;

    public ProductOrderController(IMapper mapper, DatabaseContext databaseContext)
    {
        _mapper = mapper;
        _databaseService = new DatabaseService(databaseContext);
    }
    
    #region Get

    [Route("GetProductOrder/{id}")]
    [HttpGet]
    public async Task<ProductOrder> GetProductOrder(int id)
    {
        return await _databaseService.GetProductOrder(id);
    }

    [Route("GetProductOrders")]
    [HttpGet]
    public async Task<IEnumerable<ProductOrder>> GetProductOrders()
    {
        return await _databaseService.GetProductOrders();
    }
    
    #endregion
    
    #region Add

    [Route("AddProductOrder")]
    [HttpPost]
    public async Task<IActionResult> AddProductOrder(ViewProductOrder viewProductOrder)
    {
        var ProductOrder = _mapper.Map<ProductOrder>(viewProductOrder);
        var result = await _databaseService.AddProductOrder(ProductOrder);
        return result > 0 ? new StatusCodeResult(200) : new StatusCodeResult(500);
    }
    
    [Route("AddProductOrders")]
    [HttpPost]
    public async Task<IActionResult> AddProductOrder(IEnumerable<ViewProductOrder> viewProductOrders)
    {
        var ProductOrders = _mapper.Map<IEnumerable<ProductOrder>>(viewProductOrders);
        var result = await _databaseService.AddProductOrders(ProductOrders);
        return result > 0 ? new StatusCodeResult(200) : new StatusCodeResult(500);
    }
    #endregion

    #region Update

    [Route("UpdateProductOrder")]
    [HttpPost]
    public async Task<IActionResult> UpdateProductOrder(ViewProductOrder viewProductOrder)
    {
        var ProductOrder = _mapper.Map<ProductOrder>(viewProductOrder);
        var result = await _databaseService.UpdateProductOrder(ProductOrder);
        return result > 0 ? new StatusCodeResult(200) : new StatusCodeResult(500);
    }
    
    [Route("UpdateProductOrders")]
    [HttpPost]
    public async Task<IActionResult> UpdateProductOrder(IEnumerable<ViewProductOrder> viewProductOrders)
    {
        var ProductOrders = _mapper.Map<IEnumerable<ProductOrder>>(viewProductOrders);
        var result = await _databaseService.UpdateProductOrders(ProductOrders);
        return result > 0 ? new StatusCodeResult(200) : new StatusCodeResult(500);
    }

    #endregion

    #region Delete

    [Route("DeleteProductOrder")]
    [HttpPost]
    public async Task<IActionResult> DeleteProductOrder(ViewProductOrder viewProductOrder)
    {
        var ProductOrder = _mapper.Map<ProductOrder>(viewProductOrder);
        var result = await _databaseService.RemoveProductOrder(ProductOrder);
        return result > 0 ? new StatusCodeResult(200) : new StatusCodeResult(500);
    }
    
    [Route("DeleteProductOrders")]
    [HttpPost]
    public async Task<IActionResult> DeleteProductOrder(IEnumerable<ViewProductOrder> viewProductOrders)
    {
        var ProductOrders = _mapper.Map<IEnumerable<ProductOrder>>(viewProductOrders);
        var result = await _databaseService.RemoveProductOrders(ProductOrders);
        return result > 0 ? new StatusCodeResult(200) : new StatusCodeResult(500);
    }
    #endregion
}