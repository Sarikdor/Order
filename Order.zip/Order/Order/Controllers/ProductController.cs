using AutoMapper;
using Microsoft.AspNetCore.Mvc;
using Order;
using Order.DAL.DbServices;
using Order.ViewModel;
using Order.DAL.Models;

namespace Order.Controllers;
[ApiController]
[Route("api/[controller]")]
public class ProductController : Controller
{
    private readonly IMapper _mapper;
    private readonly DatabaseService _databaseService;

    public ProductController(IMapper mapper, DatabaseContext databaseContext)
    {
        _mapper = mapper;
        _databaseService = new DatabaseService(databaseContext);
    }
    
   #region Get

    [Route("GetProduct/{id}")]
    [HttpGet]
    public async Task<Product> GetProduct(int id)
    {
        return await _databaseService.GetProduct(id);
    }

    [Route("GetProducts")]
    [HttpGet]
    public async Task<IEnumerable<Product>> GetProducts()
    {
        return await _databaseService.GetProducts();
    }

    [Route("GetProduct/{name}")]
    [HttpGet]
    public async Task<IEnumerable<Product>> GetProductsByName(string name)
    {
        return await _databaseService.GetProductByName(name);
    }


    #endregion
    
    #region Add

    [Route("AddProduct")]
    [HttpPost]
    public async Task<IActionResult> AddProduct(ViewProduct viewProduct)
    {
        var Product = _mapper.Map<Product>(viewProduct);
        var result = await _databaseService.AddProduct(Product);
        return result > 0 ? new StatusCodeResult(200) : new StatusCodeResult(500);
    }
    
    [Route("AddProducts")]
    [HttpPost]
    public async Task<IActionResult> AddProduct(IEnumerable<ViewProduct> viewProducts)
    {
        var Products = _mapper.Map<IEnumerable<Product>>(viewProducts);
        var result = await _databaseService.AddProducts(Products);
        return result > 0 ? new StatusCodeResult(200) : new StatusCodeResult(500);
    }
    #endregion

    #region Update

    [Route("UpdateProduct")]
    [HttpPost]
    public async Task<IActionResult> UpdateProduct(ViewProduct viewProduct)
    {
        var Product = _mapper.Map<Product>(viewProduct);
        var result = await _databaseService.UpdateProduct(Product);
        return result > 0 ? new StatusCodeResult(200) : new StatusCodeResult(500);
    }
    
    [Route("UpdateProducts")]
    [HttpPost]
    public async Task<IActionResult> UpdateProduct(IEnumerable<ViewProduct> viewProducts)
    {
        var Products = _mapper.Map<IEnumerable<Product>>(viewProducts);
        var result = await _databaseService.UpdateProducts(Products);
        return result > 0 ? new StatusCodeResult(200) : new StatusCodeResult(500);
    }

    #endregion

    #region Delete

    [Route("DeleteProduct")]
    [HttpPost]
    public async Task<IActionResult> DeleteProduct(ViewProduct viewProduct)
    {
        var Product = _mapper.Map<Product>(viewProduct);
        var result = await _databaseService.RemoveProduct(Product);
        return result > 0 ? new StatusCodeResult(200) : new StatusCodeResult(500);
    }
    
    [Route("DeleteProducts")]
    [HttpPost]
    public async Task<IActionResult> DeleteProduct(IEnumerable<ViewProduct> viewProducts)
    {
        var Products = _mapper.Map<IEnumerable<Product>>(viewProducts);
        var result = await _databaseService.RemoveProducts(Products);
        return result > 0 ? new StatusCodeResult(200) : new StatusCodeResult(500);
    }

    #endregion
}