using AutoMapper;
using Microsoft.AspNetCore.Mvc;
using Order.DAL.DbServices;
using Order.DAL.Models;
using Order.ViewModel;

namespace Order.Controllers;
[ApiController]
[Route("api/[controller]")]
public class CategoryController : Controller
{
    private readonly IMapper _mapper;
    private readonly DatabaseService _databaseService;

    public CategoryController(IMapper mapper, DatabaseContext databaseContext)
    {
        _mapper = mapper;
        _databaseService = new DatabaseService(databaseContext);
    }

    #region Get

    [Route("GetCategory/{id}")]
    [HttpGet]
    public async Task<Category> GetCategory(int id)
    {
        return await _databaseService.GetCategory(id);
    }

    [Route("GetCategories")]
    [HttpGet]
    public async Task<IEnumerable<Category>> GetCategories()
    {
        return await _databaseService.GetCategories();
    }

    [Route("GetCategory/{name}")]
    [HttpGet]
    public async Task<IEnumerable<Category>> GetCategoriesByName(string name)
    {
        return await _databaseService.GetCategoryByName(name);
    }


    #endregion
    
    #region Add

    [Route("AddCategory")]
    [HttpPost]
    public async Task<IActionResult> AddCategory(ViewCategory viewCategory)
    {
        var category = _mapper.Map<Category>(viewCategory);
        var result = await _databaseService.AddCategory(category);
        return result > 0 ? new StatusCodeResult(200) : new StatusCodeResult(500);
    }
    
    [Route("AddCategories")]
    [HttpPost]
    public async Task<IActionResult> AddCategory(IEnumerable<ViewCategory> viewCategories)
    {
        var categories = _mapper.Map<IEnumerable<Category>>(viewCategories);
        var result = await _databaseService.AddCategories(categories);
        return result > 0 ? new StatusCodeResult(200) : new StatusCodeResult(500);
    }
    #endregion

    #region Update

    [Route("UpdateCategory")]
    [HttpPost]
    public async Task<IActionResult> UpdateCategory(ViewCategory viewCategory)
    {
        var category = _mapper.Map<Category>(viewCategory);
        var result = await _databaseService.UpdateCategory(category);
        return result > 0 ? new StatusCodeResult(200) : new StatusCodeResult(500);
    }
    
    [Route("UpdateCategories")]
    [HttpPost]
    public async Task<IActionResult> UpdateCategory(IEnumerable<ViewCategory> viewCategories)
    {
        var categories = _mapper.Map<IEnumerable<Category>>(viewCategories);
        var result = await _databaseService.UpdateCategories(categories);
        return result > 0 ? new StatusCodeResult(200) : new StatusCodeResult(500);
    }

    #endregion

    #region Delete

    [Route("DeleteCategory")]
    [HttpPost]
    public async Task<IActionResult> DeleteCategory(ViewCategory viewCategory)
    {
        var category = _mapper.Map<Category>(viewCategory);
        var result = await _databaseService.RemoveCategory(category);
        return result > 0 ? new StatusCodeResult(200) : new StatusCodeResult(500);
    }
    
    [Route("DeleteCategories")]
    [HttpPost]
    public async Task<IActionResult> DeleteCategory(IEnumerable<ViewCategory> viewCategories)
    {
        var categories = _mapper.Map<IEnumerable<Category>>(viewCategories);
        var result = await _databaseService.RemoveCategories(categories);
        return result > 0 ? new StatusCodeResult(200) : new StatusCodeResult(500);
    }

    #endregion
}