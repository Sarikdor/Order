namespace Order.Configuration;

public class MapperConfig 
{
    
}